# Basic-Banking-System

Project developed during my GRIP Internship at The Sparks Foundation

A Basic Banking System for making money transactions between users.
No login system. No user creation. 
Direct transfer between existing users.

# Stack used in the project
FRONT END: HTML, CSS, JavaScript, Bootstrap

BACK END: PHP

DATABASE: MySQL

# Flow:
1. Home Page 
2. View all Customers 
3. Select and View one Customer 
4. Transfer Money 
5. Select Customer and Amount
6. Transfer Success
7. See Transaction History

TO RUN PROJECT save the project in 'htdocs' folder in XAMPP. 
Open xampp server and start Apache and Mysql servers.
Open Phpmyadmin and import the sql file in that.
Open browser and type the URL localhost/projectname/index.php to open the website.

Check the live website here - http://pns-web-hosting.rf.gd/
